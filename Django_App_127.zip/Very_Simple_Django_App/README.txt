VERY SIMPLE DJANGO APPLICATION

This project displays one welcome page using Django.

Run on Windows:
1. Extract the ZIP file.
2. Open Command Prompt in this folder.
3. Run: py -m pip install -r requirements.txt
4. Run: py manage.py runserver
5. Open http://127.0.0.1:8000/
