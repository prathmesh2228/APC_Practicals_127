def gross_salary(basic, allowance):
    return basic + allowance


def deductions(gross, deduction):
    return gross * deduction / 100


def net_salary(gross, deduction):
    return gross - deduction
