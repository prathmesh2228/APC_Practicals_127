from salary import gross_salary, deductions, net_salary

basic = float(input("Enter basic salary: "))
allowance = float(input("Enter allowance: "))
deduction_percent = float(input("Enter deduction percentage: "))

gross = gross_salary(basic, allowance)
deduction = deductions(gross, deduction_percent)
net = net_salary(gross, deduction)

print("\nGross Salary:", gross)
print("Deduction:", deduction)
print("Net Salary:", net)
