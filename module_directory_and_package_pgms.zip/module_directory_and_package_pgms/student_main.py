from student.marks import total_marks, percentage
from student.grade import calculate_grade
from student.attendance import attendance_percentage, is_eligible

name = input("Enter student name: ")

marks = []
n = int(input("Enter number of subjects: "))

for i in range(n):
    mark = float(input("Enter marks: "))
    marks.append(mark)

attended = int(input("Enter classes attended: "))
total_classes = int(input("Enter total classes: "))

total = total_marks(marks)
percent = percentage(marks)
grade = calculate_grade(percent)
attendance = attendance_percentage(attended, total_classes)

print("\n--- Student Report ---")
print("Name:", name)
print("Total Marks:", total)
print("Percentage:", percent)
print("Grade:", grade)
print("Attendance:", attendance)

if is_eligible(attendance):
    print("Attendance Status: Eligible")
else:
    print("Attendance Status: Not Eligible")
