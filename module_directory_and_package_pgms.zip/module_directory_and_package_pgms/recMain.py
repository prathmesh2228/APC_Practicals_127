from recursive import factorial, fibonacci, sum_digits, decimal_to_binary

n = int(input("Enter a number: "))

print("Factorial:", factorial(n))
print("Fibonacci:", fibonacci(n))
print("Sum of digits:", sum_digits(n))

if n == 0:
    print("Binary:", 0)
else:
    print("Binary:", decimal_to_binary(n))
