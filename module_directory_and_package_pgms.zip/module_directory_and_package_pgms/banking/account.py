def create_account(name, account_number, balance):
    print("Account created successfully")
    print("Account Holder:", name)
    print("Account Number:", account_number)
    print("Balance:", balance)


def check_balance(balance):
    return balance
