def calculate_loan(principal, rate, time):
    interest = (principal * rate * time) / 100
    total = principal + interest

    return interest, total
