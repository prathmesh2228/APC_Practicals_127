import student

marks = []

n = int(input("Enter number of subjects: "))

for i in range(n):
    mark = float(input("Enter marks: "))
    marks.append(mark)

total = student.total_marks(marks)
percent = student.percentage(marks)
result_grade = student.grade(percent)

print("\nTotal Marks:", total)
print("Percentage:", percent)
print("Grade:", result_grade)
