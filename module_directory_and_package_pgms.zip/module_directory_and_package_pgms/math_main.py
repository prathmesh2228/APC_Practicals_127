from mathutils.basic import add, subtract, multiply, divide
from mathutils.numbers import is_prime, is_armstrong, is_palindrome
from mathutils.statistics import mean, maximum, minimum

a = int(input("Enter first number: "))
b = int(input("Enter second number: "))

print("\nBasic Arithmetic")
print("Addition:", add(a, b))
print("Subtraction:", subtract(a, b))
print("Multiplication:", multiply(a, b))
print("Division:", divide(a, b))

n = int(input("\nEnter a number: "))

print("\nNumber Operations")
print("Prime:", is_prime(n))
print("Armstrong:", is_armstrong(n))
print("Palindrome:", is_palindrome(n))

numbers = list(map(int, input("\nEnter numbers separated by spaces: ").split()))

print("\nStatistics")
print("Mean:", mean(numbers))
print("Maximum:", maximum(numbers))
print("Minimum:", minimum(numbers))
