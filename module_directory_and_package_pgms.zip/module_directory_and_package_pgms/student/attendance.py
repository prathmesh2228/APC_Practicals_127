def attendance_percentage(attended, total):
    return (attended / total) * 100


def is_eligible(attendance):
    return attendance >= 75
