from banking.account import create_account, check_balance
from banking.transaction import deposit, withdraw
from banking.loan import calculate_loan

name = input("Enter account holder name: ")
account_number = input("Enter account number: ")
balance = float(input("Enter initial balance: "))

create_account(name, account_number, balance)

deposit_amount = float(input("\nEnter deposit amount: "))
balance = deposit(balance, deposit_amount)
print("Balance after deposit:", balance)

withdraw_amount = float(input("Enter withdrawal amount: "))
balance = withdraw(balance, withdraw_amount)
print("Balance after withdrawal:", balance)

print("Current Balance:", check_balance(balance))

principal = float(input("\nEnter loan amount: "))
rate = float(input("Enter interest rate: "))
time = float(input("Enter loan period in years: "))

interest, total = calculate_loan(principal, rate, time)

print("Loan Interest:", interest)
print("Total Loan Amount:", total)
