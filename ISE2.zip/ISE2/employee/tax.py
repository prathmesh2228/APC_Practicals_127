def taxC(salary):
    return salary *0.10
