def bon(salary):
    return salary *0.05
