def sal(basic,allow):
    return basic+allow
