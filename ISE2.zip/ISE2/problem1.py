import numpy as np

a = np.array([45, 78, 62, 90, 55, 88, 40, 72])

avg = np.mean(a)

print("Marks:", a)
print("Average Marks:", avg)

above = a[a > avg]

print("Students scoring above average:", above)
