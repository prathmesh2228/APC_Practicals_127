from employee.salary import sal
from employee.tax import taxC
from employee.bonus import bon

basic = 30000
allow = 5000

s = sal(basic, allow)
t = taxC(s)
b = bon(s)

print("Basic Salary:", basic)
print("Allowance:", allow)
print("Total Salary:", s)
print("Tax:", t)
print("Bonus:", b)

