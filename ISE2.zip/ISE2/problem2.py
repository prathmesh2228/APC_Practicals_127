
file = open("sample.txt", "r")

lines=0
words=0
ch=0

for line in file:
    lines += 1
    words += len(line.split())
    ch += len(line)

file.close()

print("Number of lines:", lines)
print("Number of words:", words)
print("Number of characters:", ch)


